"""SmartPark 运维工作台 API。启动：uvicorn app:app --host 127.0.0.1 --port 8000"""
from collections import defaultdict
from datetime import date, timedelta

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from db import init_db, connect

app = FastAPI(title="SmartPark 运维工作台")
init_db()
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def index():
    return FileResponse("static/index.html")


@app.get("/api/overview")
def overview():
    conn = connect()
    today = date.today().isoformat()
    month = today[:7]
    k = {
        "revenue_today": round(conn.execute("SELECT COALESCE(SUM(amount),0) FROM revenue WHERE day=?", (today,)).fetchone()[0], 2),
        "revenue_month": round(conn.execute("SELECT COALESCE(SUM(amount),0) FROM revenue WHERE day LIKE ?", (month + "%",)).fetchone()[0], 2),
        "orders_today": conn.execute("SELECT COALESCE(SUM(orders),0) FROM revenue WHERE day=?", (today,)).fetchone()[0],
    }
    rows = conn.execute("SELECT status, COUNT(*) n FROM equipment GROUP BY status").fetchall()
    k["equipment"] = {r["status"]: r["n"] for r in rows}
    k["equipment_total"] = sum(k["equipment"].values())
    k["repair_open"] = conn.execute("SELECT COUNT(*) FROM repair WHERE status!='已完成'").fetchone()[0]
    conn.close()
    return k


@app.get("/api/equipment")
def equipment(status: str = "", category: str = ""):
    sql, args = "SELECT * FROM equipment WHERE 1=1", []
    if status:
        sql += " AND status=?"
        args.append(status)
    if category:
        sql += " AND category=?"
        args.append(category)
    sql += " ORDER BY id"
    conn = connect()
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return [dict(r) for r in rows]


class EquipmentIn(BaseModel):
    name: str
    category: str
    lot: str
    status: str


@app.post("/api/equipment", status_code=201)
def add_equipment(body: EquipmentIn):
    conn = connect()
    code = f"NEW-{conn.execute('SELECT COUNT(*) FROM equipment').fetchone()[0] + 1:03d}"
    cur = conn.execute(
        "INSERT INTO equipment(code,name,category,lot,status,installed_on,last_check_on) VALUES(?,?,?,?,?,?,?)",
        (code, body.name, body.category, body.lot, body.status, date.today().isoformat(), date.today().isoformat()),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM equipment WHERE id=?", (cur.lastrowid,)).fetchone()
    conn.close()
    return dict(row)


class StatusIn(BaseModel):
    status: str


@app.patch("/api/equipment/{eid}")
def update_equipment(eid: int, body: StatusIn):
    if body.status not in ("正常", "故障", "待保养"):
        raise HTTPException(400, "设备状态无效")
    conn = connect()
    cur = conn.execute("UPDATE equipment SET status=?, last_check_on=? WHERE id=?",
                       (body.status, date.today().isoformat(), eid))
    if cur.rowcount == 0:
        conn.close()
        raise HTTPException(404, "设备不存在")
    conn.commit()
    row = conn.execute("SELECT * FROM equipment WHERE id=?", (eid,)).fetchone()
    conn.close()
    return dict(row)


@app.get("/api/repair")
def repairs(status: str = ""):
    sql = ("SELECT r.*, e.code equipment_code FROM repair r LEFT JOIN equipment e "
           "ON r.equipment_id=e.id WHERE 1=1")
    args = []
    if status:
        sql += " AND r.status=?"
        args.append(status)
    sql += " ORDER BY r.created_on DESC, r.id DESC"
    conn = connect()
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    return [dict(r) for r in rows]


class RepairIn(BaseModel):
    equipment_id: int
    title: str
    priority: str = "中"
    reporter: str = "值班员"


@app.post("/api/repair", status_code=201)
def add_repair(body: RepairIn):
    conn = connect()
    if not conn.execute("SELECT 1 FROM equipment WHERE id=?", (body.equipment_id,)).fetchone():
        conn.close()
        raise HTTPException(404, "设备不存在")
    cur = conn.execute(
        "INSERT INTO repair(equipment_id,title,priority,status,reporter,created_on) VALUES(?,?,?,?,?,?)",
        (body.equipment_id, body.title, body.priority, "待处理", body.reporter, date.today().isoformat()),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM repair WHERE id=?", (cur.lastrowid,)).fetchone()
    conn.close()
    return dict(row)


@app.patch("/api/repair/{rid}")
def update_repair(rid: int, body: StatusIn):
    if body.status not in ("待处理", "处理中", "已完成"):
        raise HTTPException(400, "工单状态无效")
    resolved = date.today().isoformat() if body.status == "已完成" else None
    conn = connect()
    cur = conn.execute("UPDATE repair SET status=?, resolved_on=?, handler=? WHERE id=?",
                       (body.status, resolved, "维修组" if body.status != "待处理" else "", rid))
    if cur.rowcount == 0:
        conn.close()
        raise HTTPException(404, "工单不存在")
    conn.commit()
    row = conn.execute("SELECT * FROM repair WHERE id=?", (rid,)).fetchone()
    conn.close()
    return dict(row)


@app.get("/api/revenue/daily")
def revenue_daily(days: int = 30):
    start = (date.today() - timedelta(days=max(1, days) - 1)).isoformat()
    conn = connect()
    rows = conn.execute(
        "SELECT day, ROUND(SUM(amount),2) amount, SUM(orders) orders FROM revenue "
        "WHERE day>=? GROUP BY day ORDER BY day", (start,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/revenue/monthly")
def revenue_monthly():
    conn = connect()
    rows = conn.execute(
        "SELECT substr(day,1,7) month, ROUND(SUM(amount),2) amount, SUM(orders) orders "
        "FROM revenue GROUP BY month ORDER BY month"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/revenue/sources")
def revenue_sources():
    conn = connect()
    rows = conn.execute(
        "SELECT source, ROUND(SUM(amount),2) amount, SUM(orders) orders FROM revenue GROUP BY source ORDER BY amount DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/revenue/lots")
def revenue_lots():
    conn = connect()
    rows = conn.execute(
        "SELECT lot, ROUND(SUM(amount),2) amount, SUM(orders) orders, ROUND(AVG(amount),2) avg_day "
        "FROM revenue GROUP BY lot ORDER BY amount DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@app.get("/api/parking/turnover")
def parking_turnover(days: int = 30):
    """日均周转率 = 日均停车订单 ÷ 车位数（次/日）。"""
    days = max(1, min(days, 90))
    start = (date.today() - timedelta(days=days - 1)).isoformat()
    conn = connect()
    rows = conn.execute(
        "SELECT c.lot, c.spaces, COALESCE(SUM(r.orders),0) orders "
        "FROM lot_capacity c LEFT JOIN revenue r ON r.lot=c.lot AND r.day>=? "
        "GROUP BY c.lot, c.spaces ORDER BY c.rowid", (start,)
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        avg = r["orders"] / days
        result.append({
            "lot": r["lot"], "spaces": r["spaces"], "days": days,
            "orders": r["orders"], "avg_daily_orders": round(avg, 1),
            "turnover": round(avg / r["spaces"], 2),
        })
    return result


@app.get("/api/parking/occupancy")
def parking_occupancy(days: int = 7, lot: str = ""):
    """近 N 天同一小时的平均占用 / 空闲车位。"""
    days = max(1, min(days, 90))
    start = (date.today() - timedelta(days=days - 1)).isoformat()
    sql = ("SELECT o.day, o.hour, o.occupied, c.spaces FROM occupancy o "
           "JOIN lot_capacity c ON c.lot=o.lot WHERE o.day>=?")
    args = [start]
    if lot:
        sql += " AND o.lot=?"
        args.append(lot)
    conn = connect()
    rows = conn.execute(sql, args).fetchall()
    conn.close()
    acc = defaultdict(lambda: {"occupied": 0, "spaces": 0})
    seen_days = set()
    for r in rows:
        seen_days.add(r["day"])
        acc[r["hour"]]["occupied"] += r["occupied"]
        acc[r["hour"]]["spaces"] += r["spaces"]
    n = max(1, len(seen_days))
    result = []
    for hour in range(24):
        occupied = acc[hour]["occupied"] / n
        spaces = acc[hour]["spaces"] / n
        result.append({
            "hour": hour,
            "occupied": round(occupied, 1),
            "free": round(spaces - occupied, 1),
            "spaces": round(spaces, 1),
            "rate": round(occupied / spaces * 100, 1) if spaces else 0,
        })
    return result


def _fnv32(text: str) -> int:
    h = 2166136261
    for b in text.encode("utf-8"):
        h ^= b
        h = (h * 16777619) & 0xFFFFFFFF
    return h


@app.get("/api/parking/spaces")
def parking_spaces(hour: int = 9, day: str = ""):
    """按小时给出每个车位的状态；占用数量与 occupancy 汇总一致。"""
    hour = max(0, min(23, hour))
    conn = connect()
    day = day or date.today().isoformat()
    rows = conn.execute(
        "SELECT o.hour, o.occupied, c.spaces FROM occupancy o "
        "JOIN lot_capacity c ON c.lot=o.lot WHERE o.day=?", (day,)
    ).fetchall()
    if not rows:
        day = conn.execute("SELECT MAX(day) FROM occupancy").fetchone()[0]
        rows = conn.execute(
            "SELECT o.hour, o.occupied, c.spaces FROM occupancy o "
            "JOIN lot_capacity c ON c.lot=o.lot WHERE o.day=?", (day,)
        ).fetchall()
    conn.close()
    if not rows:
        return {"day": day, "hour": hour, "spaces": 0, "occupied": 0, "free": 0, "items": []}

    counts = {r["hour"]: r["occupied"] for r in rows}
    spaces = rows[0]["spaces"]
    occupied_sets = {}
    for h in range(24):
        ranked = sorted(range(1, spaces + 1),
                        key=lambda n: _fnv32(f"{day}|{h}|{n}|smartpark"))
        occupied_sets[h] = set(ranked[:counts.get(h, 0)])

    items = []
    for n in range(1, spaces + 1):
        zone = "ABC"[min(2, (n - 1) * 3 // spaces)] + "区"
        used = sum(1 for h in range(24) if n in occupied_sets[h])
        items.append({
            "no": n, "code": f"{zone[0]}-{(n - 1) % 48 + 1:02d}", "zone": zone,
            "occupied": n in occupied_sets[hour], "used_hours": used,
        })
    current = occupied_sets[hour]
    return {
        "day": day, "hour": hour, "spaces": spaces,
        "occupied": len(current), "free": spaces - len(current), "items": items,
    }
