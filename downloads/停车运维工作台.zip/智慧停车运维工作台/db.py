"""SQLite 建表与演示数据生成。init_db() 幂等：库里有数据就跳过灌入。"""
import os
import random
import sqlite3
from datetime import date, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "smartpark.db")

LOT = "停车场"
LOTS = [LOT]
LOT_CAPACITY = {LOT: 144}
# 24 小时占用权重：夜间低、早晚高峰高；使用时按均值归一
HOUR_WEIGHTS = [
    0.15, 0.13, 0.12, 0.12, 0.16, 0.30, 0.55, 0.80,
    1.05, 1.25, 1.30, 1.22, 1.10, 1.12, 1.18, 1.25,
    1.32, 1.40, 1.28, 0.98, 0.75, 0.55, 0.38, 0.26,
]
SOURCES = ["临停", "月租", "充电", "会员"]
EQUIPMENT_CATS = ["道闸", "摄像头", "充电桩", "车位引导屏", "照明", "电梯"]
STATUS_OK, STATUS_FAULT, STATUS_MAINTAIN = "正常", "故障", "待保养"


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = connect()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            lot TEXT NOT NULL,
            status TEXT NOT NULL,
            installed_on TEXT NOT NULL,
            last_check_on TEXT NOT NULL,
            note TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS repair (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            priority TEXT NOT NULL,
            status TEXT NOT NULL,
            reporter TEXT NOT NULL,
            created_on TEXT NOT NULL,
            resolved_on TEXT,
            handler TEXT DEFAULT '',
            FOREIGN KEY(equipment_id) REFERENCES equipment(id)
        );
        CREATE TABLE IF NOT EXISTS revenue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day TEXT NOT NULL,
            lot TEXT NOT NULL,
            source TEXT NOT NULL,
            amount REAL NOT NULL,
            orders INTEGER NOT NULL,
            UNIQUE(day, lot, source)
        );
        CREATE INDEX IF NOT EXISTS idx_revenue_day ON revenue(day);
        CREATE TABLE IF NOT EXISTS lot_capacity (
            lot TEXT PRIMARY KEY,
            spaces INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS occupancy (
            day TEXT NOT NULL,
            lot TEXT NOT NULL,
            hour INTEGER NOT NULL,
            occupied INTEGER NOT NULL,
            PRIMARY KEY(day, lot, hour),
            FOREIGN KEY(lot) REFERENCES lot_capacity(lot)
        );
        CREATE INDEX IF NOT EXISTS idx_occupancy_day_hour ON occupancy(day, hour);
    """)
    count = conn.execute("SELECT COUNT(*) FROM revenue").fetchone()[0]
    if count == 0:
        _seed(conn)
    if conn.execute("SELECT COUNT(*) FROM occupancy").fetchone()[0] == 0:
        _seed_occupancy(conn)
    conn.close()


def _seed(conn):
    rnd = random.Random(20261120)
    today = date.today()

    # 设备：单个停车场，6 类各 3 台，共 18 台
    equipment = []
    for cat in EQUIPMENT_CATS:
        for idx in range(3):
            roll = rnd.random()
            status = STATUS_FAULT if roll < 0.11 else (STATUS_MAINTAIN if roll < 0.28 else STATUS_OK)
            e = (
                f"PK-{len(equipment) + 1:03d}",
                f"{LOT} {cat} {idx + 1}",
                cat,
                LOT,
                status,
                (today - timedelta(days=rnd.randint(120, 900))).isoformat(),
                (today - timedelta(days=rnd.randint(1, 60))).isoformat(),
                "巡检记录正常" if status == STATUS_OK else ("待厂家处理" if status == STATUS_FAULT else "排期中"),
            )
            cur = conn.execute(
                "INSERT INTO equipment(code,name,category,lot,status,installed_on,last_check_on,note) "
                "VALUES(?,?,?,?,?,?,?,?)", e,
            )
            equipment.append((cur.lastrowid, LOT, cat, e[1]))

    # 报修：从故障/待保养设备里生成，另有若干已完成历史单
    issues_by_cat = {
        "道闸": ["起杆卡顿", "闸杆回落异常", "读卡无响应"],
        "摄像头": ["画面模糊", "无录像", "夜视失效"],
        "充电桩": ["充电枪无法识别", "计费异常", "接口发热告警"],
        "车位引导屏": ["黑屏", "车位数字不准", "闪烁"],
        "照明": ["灯具不亮", "频闪", "感应失灵"],
        "电梯": ["异响", "平层不准", "按钮失灵"],
    }
    pending = [e for e in equipment if e[0] and rnd.random() < 0.5]
    for i, (eid, lot, cat, name) in enumerate(pending[:8]):
        created = today - timedelta(days=rnd.randint(0, 12))
        status = rnd.choice(["待处理", "处理中", "已完成"])
        resolved = created + timedelta(days=rnd.randint(1, 4)) if status == "已完成" else None
        conn.execute(
            "INSERT INTO repair(equipment_id,title,priority,status,reporter,created_on,resolved_on,handler) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (eid, f"{name}：{rnd.choice(issues_by_cat[cat])}", rnd.choice(["高", "中", "低"]), status,
             rnd.choice(["值班员-张", "值班员-李", "车主反馈"]), created.isoformat(),
             resolved.isoformat() if resolved else None,
             "维修组-王" if status != "待处理" else ""),
        )

    # 收入：近 90 天 × 4 来源
    base = {"临停": (1800, 26), "月租": (3200, 12), "充电": (600, 9), "会员": (900, 7)}
    for d in range(90):
        day = today - timedelta(days=d)
        for src in SOURCES:
            amt_base, ord_base = base[src]
            factor = 3.25 * (1.15 if day.weekday() < 5 else 0.92)
            factor *= rnd.uniform(0.82, 1.18)
            amount = round(amt_base * factor, 2)
            orders = max(1, round(ord_base * factor))
            conn.execute(
                "INSERT INTO revenue(day,lot,source,amount,orders) VALUES(?,?,?,?,?)",
                (day.isoformat(), LOT, src, amount, orders),
            )
    conn.commit()


def _seed_occupancy(conn):
    """按日均订单生成近 90 天逐小时占用演示数据。"""
    rnd = random.Random(20261121)
    today = date.today()
    start = (today - timedelta(days=89)).isoformat()
    mean_weight = sum(HOUR_WEIGHTS) / 24
    orders_by_lot = dict(conn.execute(
        "SELECT lot, SUM(orders) n FROM revenue WHERE day>=? GROUP BY lot", (start,)
    ).fetchall())

    for lot, spaces in LOT_CAPACITY.items():
        conn.execute("INSERT OR IGNORE INTO lot_capacity(lot,spaces) VALUES(?,?)", (lot, spaces))
        avg_orders = orders_by_lot.get(lot, 0) / 90
        base = min(0.72, max(0.28, 0.18 + avg_orders / spaces * 0.30))
        for d in range(90):
            day = today - timedelta(days=d)
            day_factor = 1.04 if day.weekday() < 5 else 0.94
            for hour, weight in enumerate(HOUR_WEIGHTS):
                occ = round(spaces * base * (weight / mean_weight) * day_factor * rnd.uniform(0.94, 1.06))
                occ = max(0, min(spaces - 1, occ))
                conn.execute(
                    "INSERT OR IGNORE INTO occupancy(day,lot,hour,occupied) VALUES(?,?,?,?)",
                    (day.isoformat(), lot, hour, occ),
                )
    conn.commit()
