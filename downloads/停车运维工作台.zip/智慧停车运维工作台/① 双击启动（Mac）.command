#!/bin/bash
cd "$(dirname "$0")"
echo "=========================================="
echo "  智慧停车运维工作台 · 正在启动"
echo "=========================================="
if [ ! -d ".venv" ]; then
  echo "首次运行：正在创建环境并安装依赖，请稍候..."
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install -q -r requirements.txt 2>/dev/null || pip install -q -r requirements.txt
echo ""
echo "启动完成，浏览器将自动打开工作台。"
echo "若没自动打开，请手动访问 http://127.0.0.1:8792"
echo "关闭窗口即可停止服务。"
echo ""
python 启动.py
