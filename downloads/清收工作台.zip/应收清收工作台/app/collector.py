"""清收台账：多源归集、统一口径、三项打分与商户聚合。"""

from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook

COLUMNS = {
    "project": ("项目", "项目名称", "楼盘", "商场", "物业项目"),
    "shop_no": ("铺位号", "铺位", "铺号", "档口号", "商户编号"),
    "merchant": ("商户名称", "商户", "商户名", "客户名称", "客户"),
    "fee_item": ("费项", "费用项目", "收费项目", "费用类型", "科目"),
    "receivable": ("应收金额", "应收", "欠费金额", "欠款金额", "金额"),
    "reduction": ("减免金额", "减免", "优惠金额", "折扣"),
    "age_days": ("账龄天数", "账龄", "逾期天数", "欠费天数"),
    "period": ("欠费期间", "期间", "账期", "计费期间"),
    "litigation": ("诉讼状态", "诉讼", "法务状态", "立案状态"),
    "collection": ("催缴次数", "催收次数", "发函次数", "催缴情况"),
    "exit": ("撤场迹象", "撤场", "退租意向", "经营状态"),
    "payment": ("回款情况", "回款", "缴款情况", "付款状态"),
    "risk_note": ("风险备注", "风险信号", "备注"),
}

RISK_LABELS = ("进了诉讼", "催过多次没效果", "商户快撤场", "长期零回款")
DEFAULT_WEIGHTS = {"risk": 0.40, "age": 0.35, "amount": 0.25}
AGE_CAP = 180
LEVEL_HIGH = 70
LEVEL_MID = 45


def _text(value):
    return "" if value is None else str(value).strip()


def _decimal(value, default="0"):
    text = _text(value).replace(",", "").replace("￥", "").replace("¥", "").replace("元", "")
    if not text:
        text = default
    try:
        return Decimal(text)
    except InvalidOperation:
        raise ValueError(f"金额不是有效数字：{_text(value)}")


def _int(value):
    text = _text(value)
    try:
        return int(float(text))
    except ValueError:
        return 0


def _find_columns(header):
    index = {}
    for field, names in COLUMNS.items():
        for i, name in enumerate(header):
            if name in names and field not in index:
                index[field] = i
                break
    missing = [k for k in ("merchant", "receivable") if k not in index]
    if missing:
        labels = {"merchant": "商户名称", "receivable": "应收金额"}
        raise ValueError("缺少必需列：" + "、".join(labels[k] for k in missing))
    return index


def _age_from_period(text):
    """从「2026年9-10月」这类欠费期间粗算账龄：按终止月到最后月计。"""
    import re
    from datetime import date

    nums = re.findall(r"(20\d{2})年?(\d{1,2})", text)
    if not nums:
        return 0
    year, month = int(nums[-1][0]), int(nums[-1][1])
    today = date.today()
    return max(0, (today.year - year) * 12 + today.month - month) * 30


def _risk_flags(row):
    """四个风险信号：诉讼、多次催缴无果、快撤场、长期零回款。"""
    joined = " ".join(_text(v) for v in row.values()).lower()
    flags = []
    litigation = _text(row.get("litigation"))
    if any(k in litigation.lower() for k in ("诉讼", "起诉", "立案", "已诉", "仲裁", "是", "yes", "y")):
        flags.append(RISK_LABELS[0])
    elif "诉讼" in joined and "否" not in litigation and "未" not in litigation:
        flags.append(RISK_LABELS[0])

    collection = _text(row.get("collection"))
    times = _int(collection)
    if times >= 2 or any(k in collection for k in ("多次", "反复", "无效", "催过")):
        flags.append(RISK_LABELS[1])

    exit_state = _text(row.get("exit"))
    if any(k in exit_state for k in ("撤场", "退租", "搬迁", "停业", "拟撤", "关店")):
        flags.append(RISK_LABELS[2])

    payment = _text(row.get("payment"))
    if payment in ("0", "0.00", "零", "无", "未回款", "无回款", "未缴", "零回款") or (
        _decimal(payment, "1") == 0 and payment
    ):
        flags.append(RISK_LABELS[3])

    return flags


def _read_cells(path):
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            sheet = wb.active
            return list(sheet.iter_rows(values_only=True))
        finally:
            wb.close()
    if suffix == ".csv":
        import csv

        with path.open(encoding="utf-8-sig", newline="") as fh:
            return list(csv.reader(fh))
    raise ValueError(f"不支持的文件类型：{path.name}")


def _header_of(path):
    return [_text(c) for c in _read_cells(path)[0]]


def _has_any(header, names):
    return any(n in header for n in names)


def is_risk_file(path):
    header = _header_of(path)
    has_risk = any(
        _has_any(header, COLUMNS[k])
        for k in ("litigation", "collection", "exit", "payment")
    )
    return has_risk and not _has_any(header, COLUMNS["receivable"])


def parse_risk_file(path):
    """风险状态表：按商户名归并风险信号，不产生费项行。"""
    cells = _read_cells(path)
    header = [_text(c) for c in cells[0]]
    index = {}
    for field in ("merchant", "litigation", "collection", "exit", "payment", "risk_note"):
        for i, name in enumerate(header):
            if name in COLUMNS[field] and field not in index:
                index[field] = i
                break
    if "merchant" not in index:
        raise ValueError(f"{Path(path).name} 缺少商户名称列")
    result = {}
    for line in cells[1:]:
        line = list(line) + [None] * (len(header) - len(line))
        merchant = _text(line[index["merchant"]])
        if not merchant:
            continue
        result[merchant] = {
            key: (line[index[key]] if key in index else None)
            for key in ("litigation", "collection", "exit", "payment", "risk_note")
        }
    return result


def parse_file(path):
    """解析单张表，返回扁平费项行。"""
    cells = _read_cells(path)
    if not cells:
        raise ValueError(f"{Path(path).name} 是空表")
    header = [_text(c) for c in cells[0]]
    index = _find_columns(header)
    rows = []
    for line_no, line in enumerate(cells[1:], start=2):
        line = list(line) + [None] * (len(header) - len(line))
        if not any(_text(c) for c in line):
            continue
        get = lambda key: line[index[key]] if key in index else None
        merchant = _text(get("merchant"))
        if not merchant:
            continue
        receivable = _decimal(get("receivable"))
        reduction = _decimal(get("reduction"))
        if receivable < 0 or reduction < 0:
            raise ValueError(f"{Path(path).name} 第 {line_no} 行金额不能为负")
        age = _int(get("age_days")) if "age_days" in index else 0
        if not age and "period" in index:
            age = _age_from_period(_text(get("period")))
        raw = {
            "litigation": get("litigation"),
            "collection": get("collection"),
            "exit": get("exit"),
            "payment": get("payment"),
            "risk_note": get("risk_note"),
        }
        rows.append(
            {
                "project": _text(get("project")) or "默认项目",
                "shop_no": _text(get("shop_no")),
                "merchant": merchant,
                "fee_item": _text(get("fee_item")) or "欠费",
                "receivable": f"{receivable:.2f}",
                "reduction": f"{reduction:.2f}",
                "net_amount": f"{receivable - reduction:.2f}",
                "age_days": age,
                "risk_flags": _risk_flags(raw),
                "source_file": Path(path).name,
            }
        )
    return rows


def aggregate_and_score(items, weights=None):
    """按商户聚合后三项打分、分档、排序。"""
    weights = {**DEFAULT_WEIGHTS, **(weights or {})}
    groups = {}
    for item in items:
        key = item["merchant"]
        g = groups.setdefault(
            key,
            {
                "merchant": key,
                "project_counts": {},
                "shops": [],
                "receivable": Decimal("0"),
                "reduction": Decimal("0"),
                "net": Decimal("0"),
                "age_days": 0,
                "risk_flags": set(),
                "fee_count": 0,
            },
        )
        project = item["project"]
        if project != "默认项目":
            g["project_counts"][project] = g["project_counts"].get(project, 0) + 1
        if item["shop_no"] and item["shop_no"] not in g["shops"]:
            g["shops"].append(item["shop_no"])
        g["receivable"] += Decimal(item["receivable"])
        g["reduction"] += Decimal(item["reduction"])
        g["net"] += Decimal(item["net_amount"])
        g["age_days"] = max(g["age_days"], item["age_days"])
        g["risk_flags"].update(item["risk_flags"])
        g["fee_count"] += 1

    max_net = max((g["net"] for g in groups.values()), default=Decimal("0")) or Decimal("1")
    merchants = []
    for g in groups.values():
        risk_score = len(g["risk_flags"]) / len(RISK_LABELS) * 100
        age_score = min(g["age_days"] / AGE_CAP, 1) * 100
        amount_score = float(g["net"] / max_net) * 100
        score = (
            risk_score * weights["risk"]
            + age_score * weights["age"]
            + amount_score * weights["amount"]
        )
        level = "高" if score >= LEVEL_HIGH else ("中" if score >= LEVEL_MID else "低")
        merchants.append(
            {
                "merchant": g["merchant"],
                "project": (
                    max(g["project_counts"], key=lambda k: g["project_counts"][k])
                    if g["project_counts"] else "默认项目"
                ),
                "shop_no": "、".join(g["shops"]),
                "receivable_total": f"{g['receivable']:.2f}",
                "reduction_total": f"{g['reduction']:.2f}",
                "net_total": f"{g['net']:.2f}",
                "age_days": g["age_days"],
                "risk_flags": sorted(g["risk_flags"], key=RISK_LABELS.index),
                "risk_score": round(risk_score, 1),
                "age_score": round(age_score, 1),
                "amount_score": round(amount_score, 1),
                "score": round(score, 1),
                "level": level,
                "fee_count": g["fee_count"],
            }
        )
    merchants.sort(key=lambda m: (-m["score"], -float(m["net_total"])))
    for i, m in enumerate(merchants, start=1):
        m["rank"] = i
    return merchants


def collect(paths, weights=None):
    """多表归集主入口：费项表 + 风险表 → 聚合打分结果。"""
    items = []
    risk_map = {}
    sources = []
    for path in paths:
        name = Path(path).name
        if is_risk_file(path):
            risk_map.update(parse_risk_file(path))
        else:
            items.extend(parse_file(path))
        sources.append(name)
    if not items:
        raise ValueError("没有读到任何欠费记录")

    # 风险表按商户名合并：覆盖或补充费项行里已有的信号
    for item in items:
        extra = risk_map.get(item["merchant"])
        if extra:
            merged = dict(extra)
            flags = _risk_flags(merged)
            item["risk_flags"] = sorted(set(item["risk_flags"]) | set(flags), key=RISK_LABELS.index)

    merchants = aggregate_and_score(items, weights)
    receivable_total = sum(Decimal(i["receivable"]) for i in items)
    reduction_total = sum(Decimal(i["reduction"]) for i in items)
    net_total = sum(Decimal(i["net_amount"]) for i in items)
    return {
        "sources": sources,
        "items": items,
        "merchants": merchants,
        "summary": {
            "source_count": len(sources),
            "row_count": len(items),
            "merchant_count": len(merchants),
            "project_count": len({i["project"] for i in items}),
            "fee_count": len({i["fee_item"] for i in items}),
            "receivable_total": f"{receivable_total:.2f}",
            "reduction_total": f"{reduction_total:.2f}",
            "net_total": f"{net_total:.2f}",
            "check_pass": receivable_total - reduction_total == net_total,
        },
    }
