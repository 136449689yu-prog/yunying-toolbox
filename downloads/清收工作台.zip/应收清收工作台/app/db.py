from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "engine.db"


def _connect():
    import sqlite3

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with _connect() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS arrears (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch TEXT NOT NULL,
                shop_no TEXT NOT NULL,
                merchant TEXT NOT NULL,
                amount TEXT NOT NULL,
                period TEXT,
                overdue_days TEXT,
                notice_type TEXT NOT NULL,
                reviewer TEXT,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS letters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch TEXT NOT NULL,
                arrears_id INTEGER NOT NULL,
                shop_no TEXT NOT NULL,
                notice_type TEXT NOT NULL,
                docx_name TEXT NOT NULL,
                pdf_name TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                detail TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS collection_batch (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch TEXT NOT NULL UNIQUE,
                source_files TEXT NOT NULL,
                row_count INTEGER NOT NULL,
                merchant_count INTEGER NOT NULL,
                project_count INTEGER NOT NULL DEFAULT 0,
                fee_count INTEGER NOT NULL DEFAULT 0,
                receivable_total TEXT NOT NULL,
                reduction_total TEXT NOT NULL,
                net_total TEXT NOT NULL,
                check_pass INTEGER NOT NULL,
                weights TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS collection_item (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch TEXT NOT NULL,
                project TEXT NOT NULL,
                shop_no TEXT NOT NULL,
                merchant TEXT NOT NULL,
                fee_item TEXT NOT NULL,
                receivable TEXT NOT NULL,
                reduction TEXT NOT NULL,
                net_amount TEXT NOT NULL,
                age_days INTEGER NOT NULL,
                risk_flags TEXT NOT NULL,
                source_file TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS collection_merchant (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch TEXT NOT NULL,
                merchant TEXT NOT NULL,
                project TEXT NOT NULL,
                shop_no TEXT NOT NULL,
                receivable_total TEXT NOT NULL,
                reduction_total TEXT NOT NULL,
                net_total TEXT NOT NULL,
                age_days INTEGER NOT NULL,
                risk_flags TEXT NOT NULL,
                risk_score REAL NOT NULL,
                age_score REAL NOT NULL,
                amount_score REAL NOT NULL,
                score REAL NOT NULL,
                level TEXT NOT NULL,
                rank INTEGER NOT NULL,
                fee_count INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS artifact (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                folder TEXT NOT NULL,
                name TEXT NOT NULL,
                label TEXT NOT NULL,
                meta TEXT,
                created_at TEXT NOT NULL
            );
            """
        )


def query(sql, params=()):
    with _connect() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


def execute(sql, params=()):
    with _connect() as conn:
        cur = conn.execute(sql, params)
        return cur.lastrowid
