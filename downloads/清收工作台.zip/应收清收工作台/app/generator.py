import re
from datetime import date
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt
from jinja2 import Environment, FileSystemLoader
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

BASE = Path(__file__).resolve().parent.parent
OUTPUT = BASE / "data" / "output"
FONT = "STSong-Light"
pdfmetrics.registerFont(UnicodeCIDFont(FONT))

_env = Environment(loader=FileSystemLoader(BASE / "templates"), autoescape=False)


def _today():
    return date.today().strftime("%Y年%m月%d日")


def render(row, settings):
    name = "first.j2" if row["notice_type"] == "一次函" else "second.j2"
    context = {**settings, **row, "today": _today()}
    return _env.get_template(name).render(**context).strip()


def _title(notice_type):
    return "催费通知书（第一次）" if notice_type == "一次函" else "催费通知书（第二次）"


def _safe(text):
    return re.sub(r'[\\/:*?"<>|]', "_", str(text)).strip() or "unnamed"


def write_docx(path, title, body, settings):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(11)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    head = doc.add_paragraph()
    head.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = head.add_run(title)
    run.bold = True
    run.font.size = Pt(17)
    run.font.name = "宋体"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    for line in body.splitlines():
        doc.add_paragraph(line)
    for line in (settings["company"], _today()):
        para = doc.add_paragraph(line)
        para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    doc.save(path)


def _wrap(text, width, size):
    lines, current = [], ""
    for char in text:
        if current and pdfmetrics.stringWidth(current + char, FONT, size) > width:
            lines.append(current)
            current = char
        else:
            current += char
    if current:
        lines.append(current)
    return lines or [""]


def write_pdf(path, title, body, settings):
    page_w, page_h = A4
    left = right = 60
    c = canvas.Canvas(str(path), pagesize=A4)
    y = page_h - 72

    c.setFont(FONT, 17)
    c.drawCentredString(page_w / 2, y, title)
    y -= 42

    c.setFont(FONT, 11)
    for line in body.splitlines():
        if not line.strip():
            y -= 10
            continue
        for piece in _wrap(line, page_w - left - right, 11):
            if y < 78:
                c.showPage()
                y = page_h - 72
                c.setFont(FONT, 11)
            c.drawString(left, y, piece)
            y -= 20

    y -= 14
    for line in (settings["company"], _today()):
        if y < 78:
            c.showPage()
            y = page_h - 72
        c.setFont(FONT, 11)
        c.drawRightString(page_w - right, y, line)
        y -= 20
    c.save()


def generate_batch(batch, rows, settings):
    folder = OUTPUT / batch
    folder.mkdir(parents=True, exist_ok=True)
    records = []
    for row in rows:
        body = render(row, settings)
        base = f"{_safe(row['shop_no'])}_{row['notice_type']}"
        docx_name = f"{base}.docx"
        pdf_name = f"{base}.pdf"
        write_docx(folder / docx_name, _title(row["notice_type"]), body, settings)
        write_pdf(folder / pdf_name, _title(row["notice_type"]), body, settings)
        records.append(
            {
                "arrears_id": row["id"],
                "shop_no": row["shop_no"],
                "notice_type": row["notice_type"],
                "docx_name": docx_name,
                "pdf_name": pdf_name,
            }
        )

    zip_name = f"催费函_{batch}.zip"
    with ZipFile(folder / zip_name, "w", ZIP_DEFLATED) as archive:
        for r in records:
            archive.write(folder / r["docx_name"], r["docx_name"])
            archive.write(folder / r["pdf_name"], r["pdf_name"])
    return records, zip_name
