from decimal import Decimal, InvalidOperation
from pathlib import Path

from openpyxl import load_workbook

COLUMNS = {
    "shop_no": ("铺位号", "铺位", "铺号", "档口号"),
    "merchant": ("商户名称", "商户", "商户名", "客户名称"),
    "amount": ("欠费金额", "应收金额", "金额", "欠款金额"),
    "period": ("欠费期间", "计费期间", "期间", "账期"),
    "overdue_days": ("逾期天数", "逾期", "欠费天数"),
    "notice_type": ("函件类型", "催费次数", "函件类别", "类型"),
    "reviewer": ("复核人", "审核人", "复核"),
    "review_status": ("复核状态", "审核状态", "财务复核"),
}

FIRST = ("一次", "一次函", "初次", "首次", "1", "第一次")
SECOND = ("二次", "二次函", "再次", "2", "第二次")
REVIEWED = ("已复核", "已审核", "复核通过", "通过", "已确认", "是", "yes", "y")


def _text(value):
    if value is None:
        return ""
    return str(value).strip()


def _amount(value):
    text = _text(value).replace(",", "").replace("￥", "").replace("元", "")
    try:
        return f"{Decimal(text):.2f}"
    except (InvalidOperation, ValueError):
        raise ValueError(f"欠费金额不是有效数字：{_text(value)}")


def _notice_type(value):
    text = _text(value)
    if text in SECOND:
        return "二次函"
    if text in FIRST:
        return "一次函"
    raise ValueError(f"函件类型无法识别：{text or '（空）'}，请填「一次」或「二次」")


def _find_columns(header):
    index = {}
    for field, names in COLUMNS.items():
        for i, name in enumerate(header):
            if name in names:
                index[field] = i
                break
    missing = [k for k in ("shop_no", "merchant", "amount") if k not in index]
    if missing:
        labels = {"shop_no": "铺位号", "merchant": "商户名称", "amount": "欠费金额"}
        raise ValueError("缺少必需列：" + "、".join(labels[k] for k in missing))
    return index


def _rows_from_cells(cells):
    if not cells:
        raise ValueError("表格是空的")
    header = [_text(c) for c in cells[0]]
    index = _find_columns(header)
    result = []
    for line_no, row in enumerate(cells[1:], start=2):
        row = list(row) + [None] * (len(header) - len(row))
        if not any(_text(c) for c in row):
            continue
        record = {
            "shop_no": _text(row[index["shop_no"]]),
            "merchant": _text(row[index["merchant"]]),
            "amount": _amount(row[index["amount"]]),
            "period": _text(row[index["period"]]) if "period" in index else "",
            "overdue_days": _text(row[index["overdue_days"]]) if "overdue_days" in index else "",
            "notice_type": _notice_type(row[index["notice_type"]]) if "notice_type" in index else "一次函",
            "reviewer": _text(row[index["reviewer"]]) if "reviewer" in index else "",
        }
        if "review_status" in index:
            status = _text(row[index["review_status"]])
            if status.lower() not in REVIEWED:
                continue
        if not record["shop_no"] or not record["merchant"]:
            raise ValueError(f"第 {line_no} 行缺少铺位号或商户名称")
        result.append(record)
    if not result:
        raise ValueError("没有已复核的记录")
    return result


def parse(path):
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            sheet = wb.active
            cells = list(sheet.iter_rows(values_only=True))
        finally:
            wb.close()
    elif suffix == ".csv":
        import csv

        with path.open(encoding="utf-8-sig", newline="") as fh:
            cells = list(csv.reader(fh))
    else:
        raise ValueError("只支持 .xlsx / .xlsm / .csv 文件")
    return _rows_from_cells(cells)
