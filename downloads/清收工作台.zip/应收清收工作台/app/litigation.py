"""诉讼材料清单：按商户生成证据目录与待补材料，附 Excel 汇总。"""

from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.shared import Pt
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

BASE = Path(__file__).resolve().parent.parent
OUTPUT = BASE / "data" / "output"


def _safe(text):
    out = ""
    for ch in str(text):
        out += "_" if ch in '\\/:*?"<>|' else ch
    return out.strip() or "unnamed"


def _money(v):
    return f"{float(v or 0):,.2f}"


def _flags(text):
    return [x for x in str(text or "").split("、") if x]


EVIDENCE = [
    ("租赁合同及补充协议", "证明租赁关系、缴费约定与违约责任"),
    ("欠费明细表", "证明欠费期间、费项构成与实欠金额"),
    ("减免审批记录", "证明实欠金额已扣除减免，口径一致"),
    ("催缴函及送达凭证", "证明已履行催告义务、给予合理期限"),
    ("商户主体资料", "营业执照或身份证，确定被告主体资格"),
    ("往来沟通记录", "微信、邮件、通话记录，证明催收经过"),
    ("回款流水", "证明已缴与未缴金额，核对余额"),
]

EXTRA_EVIDENCE = {
    "进了诉讼": ("立案通知书或受理凭证", "证明已进入诉讼程序"),
    "催过多次没效果": ("历次催缴函与送达回执", "证明多次催告无果"),
    "商户快撤场": ("撤场通知、现场照片或退租申请", "证明对方存在逃废债风险"),
    "长期零回款": ("账期对账单与催款记录", "证明长期未履行付款义务"),
}


def _merchant_items(state, merchant):
    return [i for i in state["items"] if i["merchant"] == merchant]


def _write_docx(path, m, items, settings):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "宋体"
    style.font.size = Pt(11)
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    h = doc.add_paragraph()
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = h.add_run(f"诉讼材料清单 · {m['merchant']}")
    run.bold = True
    run.font.size = Pt(16)
    run.font.name = "宋体"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")

    doc.add_paragraph(f"编制日期：{date.today().strftime('%Y年%m月%d日')}　　优先级：{m['level']}（{float(m['score']):.1f} 分）")

    doc.add_heading("一、案件基本信息", level=2)
    for label, value in (
        ("商户名称", m["merchant"]),
        ("所属项目 / 铺位", f"{m['project']} / {m['shop_no'] or '—'}"),
        ("实欠金额", f"¥{_money(m['net_total'])}（应收 ¥{_money(m['receivable_total'])} − 减免 ¥{_money(m['reduction_total'])}）"),
        ("账龄", f"{m['age_days']} 天"),
        ("风险信号", "、".join(_flags(m["risk_flags"])) or "无"),
    ):
        doc.add_paragraph(f"{label}：{value}")

    doc.add_heading("二、欠费构成", level=2)
    table = doc.add_table(rows=1, cols=4)
    table.style = "Light Grid Accent 1"
    for cell, text in zip(table.rows[0].cells, ("费项", "应收", "减免", "实欠")):
        cell.text = text
    for item in items:
        cells = table.add_row().cells
        cells[0].text = item["fee_item"]
        cells[1].text = _money(item["receivable"])
        cells[2].text = _money(item["reduction"])
        cells[3].text = _money(item["net_amount"])
    cells = table.add_row().cells
    cells[0].text = "合计"
    cells[1].text = _money(m["receivable_total"])
    cells[2].text = _money(m["reduction_total"])
    cells[3].text = _money(m["net_total"])

    doc.add_heading("三、必备证据目录", level=2)
    for i, (name, purpose) in enumerate(EVIDENCE, 1):
        doc.add_paragraph(f"□ {i}. {name} —— {purpose}")

    extra = [(EXTRA_EVIDENCE[f][0], EXTRA_EVIDENCE[f][1]) for f in _flags(m["risk_flags"]) if f in EXTRA_EVIDENCE]
    if extra:
        doc.add_heading("四、按风险信号补充的证据", level=2)
        for i, (name, purpose) in enumerate(extra, 1):
            doc.add_paragraph(f"□ {i}. {name} —— {purpose}")

    doc.add_heading("五、起诉状要素", level=2)
    for text in (
        f"原告：{settings['company']}",
        f"被告：{m['merchant']}（{m['project']} {m['shop_no'] or '—'}）",
        f"诉讼请求：判令被告支付欠费 ¥{_money(m['net_total'])}，并承担违约金及本案诉讼费用",
        f"事实与理由：被告自 {m['age_days']} 天前起拖欠上述费用，经多次催告仍未清偿",
        "管辖法院：场地所在地有管辖权的人民法院",
    ):
        doc.add_paragraph(text)

    tail = doc.add_paragraph()
    tail.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    tail.add_run(settings["company"])
    doc.save(path)


def _write_xlsx(path, merchants, state):
    wb = Workbook()
    ws = wb.active
    ws.title = "诉讼材料清单汇总"
    header = ["序号", "优先级", "商户", "项目 / 铺位", "实欠金额", "账龄天数", "风险信号", "必备证据", "补充证据", "清单文件", "准备状态"]
    ws.append(header)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0066CC")
        c.alignment = Alignment(horizontal="center")
    for i, m in enumerate(merchants, 1):
        flags = _flags(m["risk_flags"])
        extra = [EXTRA_EVIDENCE[f][0] for f in flags if f in EXTRA_EVIDENCE]
        ws.append([
            i, m["level"], m["merchant"], f"{m['project']} / {m['shop_no'] or '—'}",
            float(m["net_total"]), m["age_days"], "、".join(flags) or "无",
            f"{len(EVIDENCE)} 项", f"{len(extra)} 项" if extra else "无",
            f"{_safe(m['merchant'])}_诉讼材料清单.docx", "待准备",
        ])
    widths = [8, 10, 20, 24, 14, 12, 28, 12, 12, 36, 12]
    for col, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.freeze_panes = "A2"
    wb.save(path)


def build(state, merchant_names, settings):
    """生成选中商户的诉讼材料清单，返回汇总表与每户清单。"""
    if not state:
        raise ValueError("请先归集清收台账")
    wanted = set(merchant_names)
    merchants = [m for m in state["merchants"] if m["merchant"] in wanted]
    if not merchants:
        raise ValueError("没有选中的商户")

    folder = OUTPUT / f"{state['batch']}_诉讼"
    folder.mkdir(parents=True, exist_ok=True)
    records = []
    for m in merchants:
        name = f"{_safe(m['merchant'])}_诉讼材料清单.docx"
        _write_docx(folder / name, m, _merchant_items(state, m["merchant"]), settings)
        records.append({"merchant": m["merchant"], "level": m["level"], "docx_name": name})

    xlsx_name = "诉讼材料清单汇总.xlsx"
    _write_xlsx(folder / xlsx_name, merchants, state)
    return {"folder": folder.name, "records": records, "xlsx_name": xlsx_name}
