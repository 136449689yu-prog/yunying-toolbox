from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import collector, db, generator, importer, litigation, models, monthly

BASE = Path(__file__).resolve().parent.parent


@asynccontextmanager
async def lifespan(app):
    db.init_db()
    yield


app = FastAPI(title="催费函生成工具", lifespan=lifespan)


def _batch():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


@app.get("/api/state")
def state():
    batch = models.current_batch()
    return {
        "settings": models.get_settings(),
        "rows": models.list_arrears(batch),
        "batch": batch,
        "letters": models.list_letters(batch) if batch else [],
        "audit": models.list_audit(),
    }


@app.post("/api/settings")
async def settings_save(payload: dict):
    result = models.save_settings(payload)
    models.add_audit("保存函件信息", "更新公司、账户与联系人设置")
    return result


@app.post("/api/import")
async def import_file(file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in (".xlsx", ".xlsm", ".csv"):
        raise HTTPException(400, "只支持 .xlsx / .xlsm / .csv 文件")
    batch = _batch()
    upload_dir = BASE / "data" / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved = upload_dir / f"{batch}_{Path(file.filename).name}"
    saved.write_bytes(await file.read())
    try:
        rows = importer.parse(saved)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    models.replace_arrears(batch, rows)
    return {"batch": batch, "count": len(rows), "rows": models.list_arrears(batch)}


@app.post("/api/generate")
async def generate(payload: dict):
    ids = payload.get("ids")
    batch = payload.get("batch") or models.current_batch()
    if not batch:
        raise HTTPException(400, "请先导入复核表")
    rows = models.list_arrears(batch)
    if ids:
        rows = [r for r in rows if r["id"] in ids]
    if not rows:
        raise HTTPException(400, "没有选中的记录")
    settings = models.get_settings()
    records, zip_name = generator.generate_batch(batch, rows, settings)
    models.add_letters(batch, records)
    models.add_audit("生成催费函", f"批次 {batch}，{len(records)} 份，Word + PDF")
    return {"batch": batch, "count": len(records), "zip": zip_name, "letters": models.list_letters(batch)}


@app.get("/api/download/{batch}/{name}")
def download(batch: str, name: str):
    if Path(name).name != name or Path(batch).name != batch:
        raise HTTPException(400, "非法文件名")
    path = generator.OUTPUT / batch / name
    if not path.is_file():
        raise HTTPException(404, "文件不存在")
    return FileResponse(path, filename=name)


@app.get("/api/template")
def template_download():
    path = BASE / "data" / "复核表模板.xlsx"
    if not path.is_file():
        raise HTTPException(404, "模板不存在")
    return FileResponse(path, filename="复核表模板.xlsx")


@app.get("/api/workspace/state")
def workspace_state():
    """统一工作台一次取齐：归集结果、函件、设置、操作记录。"""
    batch = models.current_batch()
    return {
        "collection": models.get_collection_state(),
        "letter_batch": batch,
        "rows": models.list_arrears(batch),
        "letters": models.list_letters(batch) if batch else [],
        "settings": models.get_settings(),
        "audit": models.list_audit(),
        "artifacts": models.get_artifacts(),
    }


@app.post("/api/collection/generate")
async def collection_generate(payload: dict):
    """从分级清单直接出函：金额取实欠，账龄取归集结果，函件类型逐条指定。"""
    chosen = payload.get("merchants") or []
    state = models.get_collection_state()
    if not state:
        raise HTTPException(400, "请先归集清收台账")
    wanted = {str(x.get("merchant", "")): x.get("notice_type", "一次函") for x in chosen}
    merchants = [m for m in state["merchants"] if m["merchant"] in wanted]
    if not merchants:
        raise HTTPException(400, "没有选中的商户")

    rows = []
    for i, m in enumerate(merchants, 1):
        detail = [x for x in state["items"] if x["merchant"] == m["merchant"]]
        lines = "\n".join(
            f"· {x['fee_item']}：¥{float(x['net_amount']):,.2f}"
            f"（应收 ¥{float(x['receivable']):,.2f}，减免 ¥{float(x['reduction']):,.2f}）"
            for x in detail
        )
        months = max(1, round(int(m["age_days"] or 0) / 30))
        rows.append({
            "id": i,
            "shop_no": m["shop_no"] or "—",
            "merchant": m["merchant"],
            "amount": m["net_total"],
            "period": f"最近 {months} 个月",
            "overdue_days": m["age_days"],
            "notice_type": wanted[m["merchant"]],
            "reviewer": "清收台账",
            "item_lines": lines,
            "risk_text": "、".join(f for f in str(m["risk_flags"] or "").split("、") if f),
        })

    batch = datetime.now().strftime("LT%Y%m%d-%H%M%S")
    settings = models.get_settings()
    models.replace_arrears(batch, rows, audit_action=None)
    records, zip_name = generator.generate_batch(batch, rows, settings)
    models.add_letters(batch, records)
    models.add_audit("清收台账出函", f"批次 {batch}，{len(records)} 份，Word + PDF")
    return {
        "batch": batch,
        "count": len(records),
        "zip": zip_name,
        "letters": models.list_letters(batch),
    }


@app.post("/api/collection/litigation")
async def collection_litigation(payload: dict):
    names = payload.get("merchants") or []
    state = models.get_collection_state()
    result = litigation.build(state, names, models.get_settings())
    rows = [{"folder": result["folder"], "name": result["xlsx_name"],
             "label": f"材料清单汇总（{len(result['records'])} 户）"}]
    for r in result["records"]:
        rows.append({"folder": result["folder"], "name": r["docx_name"],
                     "label": f"{r['merchant']} · {r['level']}优先级"})
    models.save_artifacts("litigation", rows)
    models.add_audit("生成诉讼材料清单", f"{len(result['records'])} 户，含 Excel 汇总")
    return result


@app.get("/api/collection/monthly")
def collection_monthly():
    state = models.get_collection_state()
    result = monthly.build(state, len(models.list_letters()))
    models.save_artifacts("monthly", [{
        "folder": result["folder"], "name": result["xlsx_name"],
        "label": f"月度清收进展 {result['summary']['month']}",
        "meta": result["summary"],
    }])
    models.add_audit("生成月度清收进展", f"{result['summary']['month']}，{result['summary']['merchant_count']} 商户")
    return result


@app.get("/collection", response_class=FileResponse)
def collection_page():
    return FileResponse(BASE / "static" / "collection.html")


@app.get("/api/collection/state")
def collection_state():
    return {"state": models.get_collection_state()}


@app.post("/api/collection/import")
async def collection_import(files: list[UploadFile] = File(...)):
    upload_dir = BASE / "data" / "collection_uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved_paths = []
    for upload in files:
        suffix = Path(upload.filename or "").suffix.lower()
        if suffix not in (".xlsx", ".xlsm", ".csv"):
            raise HTTPException(400, f"不支持的文件类型：{upload.filename}")
        dest = upload_dir / Path(upload.filename).name
        dest.write_bytes(await upload.read())
        saved_paths.append(dest)
    try:
        result = collector.collect(saved_paths)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    batch = datetime.now().strftime("CL%Y%m%d-%H%M%S")
    state = models.save_collection(batch, result)
    return {"batch": batch, "summary": state, "state": state}


@app.post("/api/collection/load-sample")
def collection_load_sample():
    sample_dir = BASE / "data" / "collection_sample"
    files = sorted(p for p in sample_dir.iterdir() if p.suffix.lower() in (".xlsx", ".csv"))
    if not files:
        raise HTTPException(404, "模拟数据不存在，请先运行 scripts/make_collection_sample.py")
    result = collector.collect(files)
    batch = datetime.now().strftime("CL%Y%m%d-%H%M%S")
    state = models.save_collection(batch, result)
    return {"batch": batch, "state": state}


@app.get("/api/collection/template")
def collection_template():
    """打包所有模拟表供用户参考字段口径。"""
    import io
    import zipfile

    sample_dir = BASE / "data" / "collection_sample"
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(sample_dir.glob("*")):
            zf.write(path, path.name)
    buf.seek(0)
    from fastapi.responses import StreamingResponse

    return StreamingResponse(
        buf, media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="collection_sample.zip"'},
    )


@app.get("/", response_class=FileResponse)
def workspace_page():
    return FileResponse(BASE / "static" / "workspace.html")


app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
