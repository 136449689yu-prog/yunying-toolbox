from datetime import datetime

from . import db

DEFAULT_SETTINGS = {
    "company": "XX商业管理有限公司",
    "bank": "",
    "account": "",
    "contact": "营运部",
    "phone": "",
}


def get_settings():
    saved = {r["key"]: r["value"] for r in db.query("SELECT key, value FROM settings")}
    return {**DEFAULT_SETTINGS, **saved}


def save_settings(values):
    for key in DEFAULT_SETTINGS:
        if key in values:
            db.execute(
                "INSERT INTO settings(key, value) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, str(values[key]).strip()),
            )
    return get_settings()


def replace_arrears(batch, rows, audit_action="导入复核表"):
    now = datetime.now().isoformat(timespec="seconds")
    with db._connect() as conn:
        conn.execute("DELETE FROM arrears")
        conn.executemany(
            "INSERT INTO arrears(batch, shop_no, merchant, amount, period, "
            "overdue_days, notice_type, reviewer, created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            [
                (
                    batch,
                    r["shop_no"],
                    r["merchant"],
                    r["amount"],
                    r.get("period", ""),
                    r.get("overdue_days", ""),
                    r["notice_type"],
                    r.get("reviewer", ""),
                    now,
                )
                for r in rows
            ],
        )
    if audit_action:
        add_audit(audit_action, f"批次 {batch}，{len(rows)} 条记录")


def list_arrears(batch=None):
    if batch:
        return db.query("SELECT * FROM arrears WHERE batch = ? ORDER BY id", (batch,))
    return db.query("SELECT * FROM arrears ORDER BY id")


def current_batch():
    rows = db.query("SELECT batch FROM arrears ORDER BY id DESC LIMIT 1")
    return rows[0]["batch"] if rows else None


def add_letters(batch, records):
    now = datetime.now().isoformat(timespec="seconds")
    with db._connect() as conn:
        conn.executemany(
            "INSERT INTO letters(batch, arrears_id, shop_no, notice_type, "
            "docx_name, pdf_name, created_at) VALUES(?,?,?,?,?,?,?)",
            [
                (
                    batch,
                    r["arrears_id"],
                    r["shop_no"],
                    r["notice_type"],
                    r["docx_name"],
                    r["pdf_name"],
                    now,
                )
                for r in records
            ],
        )


def list_letters(batch=None):
    if batch:
        return db.query("SELECT * FROM letters WHERE batch = ? ORDER BY id", (batch,))
    return db.query("SELECT * FROM letters ORDER BY id DESC LIMIT 200")


def add_audit(action, detail):
    db.execute(
        "INSERT INTO audit(action, detail, created_at) VALUES(?,?,?)",
        (action, detail, datetime.now().isoformat(timespec="seconds")),
    )


def list_audit():
    return db.query("SELECT * FROM audit ORDER BY id DESC LIMIT 50")


def save_collection(batch, result):
    """把归集分级结果写入独立表，不碰现有催费函数据。"""
    summary = result["summary"]
    weights = "40/35/25"
    now = datetime.now().isoformat(timespec="seconds")
    with db._connect() as conn:
        conn.execute("DELETE FROM collection_batch")
        conn.execute("DELETE FROM collection_item")
        conn.execute("DELETE FROM collection_merchant")
        conn.execute(
            "INSERT INTO collection_batch(batch, source_files, row_count, merchant_count, "
            "project_count, fee_count, receivable_total, reduction_total, net_total, "
            "check_pass, weights, created_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                batch,
                "、".join(result["sources"]),
                summary["row_count"],
                summary["merchant_count"],
                summary["project_count"],
                summary["fee_count"],
                summary["receivable_total"],
                summary["reduction_total"],
                summary["net_total"],
                1 if summary["check_pass"] else 0,
                weights,
                now,
            ),
        )
        conn.executemany(
            "INSERT INTO collection_item(batch, project, shop_no, merchant, fee_item, "
            "receivable, reduction, net_amount, age_days, risk_flags, source_file) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            [
                (
                    batch,
                    i["project"],
                    i["shop_no"],
                    i["merchant"],
                    i["fee_item"],
                    i["receivable"],
                    i["reduction"],
                    i["net_amount"],
                    i["age_days"],
                    "、".join(i["risk_flags"]),
                    i["source_file"],
                )
                for i in result["items"]
            ],
        )
        conn.executemany(
            "INSERT INTO collection_merchant(batch, merchant, project, shop_no, "
            "receivable_total, reduction_total, net_total, age_days, risk_flags, "
            "risk_score, age_score, amount_score, score, level, rank, fee_count) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [
                (
                    batch,
                    m["merchant"],
                    m["project"],
                    m["shop_no"],
                    m["receivable_total"],
                    m["reduction_total"],
                    m["net_total"],
                    m["age_days"],
                    "、".join(m["risk_flags"]),
                    m["risk_score"],
                    m["age_score"],
                    m["amount_score"],
                    m["score"],
                    m["level"],
                    m["rank"],
                    m["fee_count"],
                )
                for m in result["merchants"]
            ],
        )
    add_audit("归集清收台账", f"批次 {batch}，{summary['row_count']} 条费项 / {summary['merchant_count']} 商户，合计校验{'通过' if summary['check_pass'] else '不通过'}")
    return get_collection_state()


def get_collection_state():
    batches = db.query("SELECT * FROM collection_batch ORDER BY id DESC LIMIT 1")
    if not batches:
        return None
    batch = batches[0]
    merchants = db.query("SELECT * FROM collection_merchant WHERE batch = ? ORDER BY rank", (batch["batch"],))
    items = db.query("SELECT * FROM collection_item WHERE batch = ? ORDER BY id", (batch["batch"],))
    return {**batch, "merchants": merchants, "items": items}


def save_artifacts(kind, rows):
    """记录最近一次产出，让页面刷新后仍能看到下载入口。"""
    import json
    from datetime import datetime

    now = datetime.now().isoformat(timespec="seconds")
    with db._connect() as conn:
        conn.execute("DELETE FROM artifact WHERE kind = ?", (kind,))
        conn.executemany(
            "INSERT INTO artifact(kind, folder, name, label, meta, created_at) "
            "VALUES(?,?,?,?,?,?)",
            [
                (kind, r["folder"], r["name"], r["label"],
                 json.dumps(r.get("meta"), ensure_ascii=False) if r.get("meta") is not None else None,
                 now)
                for r in rows
            ],
        )


def get_artifacts():
    import json

    rows = db.query("SELECT * FROM artifact ORDER BY id")
    out = {"litigation": [], "monthly": None}
    for r in rows:
        item = {"folder": r["folder"], "name": r["name"], "label": r["label"]}
        if r["kind"] == "litigation":
            out["litigation"].append(item)
        elif r["kind"] == "monthly":
            out["monthly"] = {**item, "summary": json.loads(r["meta"]) if r["meta"] else None}
    return out
