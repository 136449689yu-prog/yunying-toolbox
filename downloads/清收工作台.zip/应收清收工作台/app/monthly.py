"""月度清收进展：按月汇总归集结果，输出 Excel 月报与图表数据。"""

from datetime import date
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

BASE = Path(__file__).resolve().parent.parent
OUTPUT = BASE / "data" / "output"

LEVELS = ("高", "中", "低")
RISKS = ("进了诉讼", "催过多次没效果", "商户快撤场", "长期零回款")


def _flags(text):
    return [x for x in str(text or "").split("、") if x]


def _style_header(ws, widths):
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0066CC")
        c.alignment = Alignment(horizontal="center")
    for col, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.freeze_panes = "A2"


def summarize(state, letters=0):
    """从归集结果算月报指标，供页面图表与 Excel 共用。"""
    if not state:
        raise ValueError("请先归集清收台账")
    merchants = state["merchants"]
    items = state["items"]
    total = lambda rows: sum(float(r["net_total"] if "net_total" in r else r["net_amount"]) for r in rows)

    levels = []
    for level in LEVELS:
        group = [m for m in merchants if m["level"] == level]
        levels.append({"level": level, "count": len(group), "amount": round(total(group), 2)})

    projects = {}
    for m in merchants:
        p = projects.setdefault(m["project"], {"project": m["project"], "count": 0, "amount": 0.0, "high": 0})
        p["count"] += 1
        p["amount"] += float(m["net_total"])
        if m["level"] == "高":
            p["high"] += 1
    projects = sorted(projects.values(), key=lambda x: -x["amount"])

    fees = {}
    for i in items:
        f = fees.setdefault(i["fee_item"], {"fee": i["fee_item"], "count": 0, "amount": 0.0})
        f["count"] += 1
        f["amount"] += float(i["net_amount"])
    fees = sorted(fees.values(), key=lambda x: -x["amount"])

    risks = []
    for flag in RISKS:
        group = [m for m in merchants if flag in _flags(m["risk_flags"])]
        risks.append({"flag": flag, "count": len(group), "amount": round(total(group), 2)})

    litigation = [m for m in merchants if "进了诉讼" in _flags(m["risk_flags"])]
    return {
        "month": date.today().strftime("%Y-%m"),
        "merchant_count": len(merchants),
        "row_count": len(items),
        "project_count": len(projects),
        "net_total": round(total(merchants), 2),
        "receivable_total": round(sum(float(m["receivable_total"]) for m in merchants), 2),
        "reduction_total": round(sum(float(m["reduction_total"]) for m in merchants), 2),
        "letter_count": letters,
        "litigation_count": len(litigation),
        "litigation_amount": round(total(litigation), 2),
        "levels": levels,
        "projects": projects,
        "fees": fees,
        "risks": risks,
    }


def _write_xlsx(path, s):
    wb = Workbook()

    ws = wb.active
    ws.title = "月度概览"
    rows = [
        ("统计月份", s["month"]),
        ("归集商户", s["merchant_count"]),
        ("费项条数", s["row_count"]),
        ("涉及项目", s["project_count"]),
        ("应收合计", s["receivable_total"]),
        ("减免合计", s["reduction_total"]),
        ("实欠合计", s["net_total"]),
        ("已出催缴函", s["letter_count"]),
        ("进入诉讼商户", s["litigation_count"]),
        ("涉诉金额", s["litigation_amount"]),
    ]
    ws.append(["指标", "数值"])
    for r in rows:
        ws.append(r)
    _style_header(ws, [20, 20])
    for row in ws.iter_rows(min_row=2, max_col=2):
        if row[0].value in ("应收合计", "减免合计", "实欠合计", "涉诉金额"):
            row[1].number_format = '#,##0.00'
            row[1].font = Font(bold=True)

    ws = wb.create_sheet("优先级分档")
    ws.append(["等级", "商户数", "实欠金额"])
    for x in s["levels"]:
        ws.append([x["level"], x["count"], x["amount"]])
    _style_header(ws, [12, 12, 18])
    chart = BarChart()
    chart.title = "各优先级商户数"
    chart.y_axis.title = "商户数"
    chart.add_data(Reference(ws, min_col=2, min_row=1, max_row=4), titles_from_data=True)
    chart.set_categories(Reference(ws, min_col=1, min_row=2, max_row=4))
    chart.height, chart.width = 7, 12
    ws.add_chart(chart, "E2")

    ws = wb.create_sheet("项目汇总")
    ws.append(["项目", "商户数", "实欠金额", "高风险商户"])
    for x in s["projects"]:
        ws.append([x["project"], x["count"], round(x["amount"], 2), x["high"]])
    _style_header(ws, [22, 12, 18, 14])

    ws = wb.create_sheet("费项汇总")
    ws.append(["费项", "条数", "实欠金额"])
    for x in s["fees"]:
        ws.append([x["fee"], x["count"], round(x["amount"], 2)])
    _style_header(ws, [22, 12, 18])

    ws = wb.create_sheet("风险信号")
    ws.append(["风险信号", "商户数", "涉及实欠"])
    for x in s["risks"]:
        ws.append([x["flag"], x["count"], x["amount"]])
    _style_header(ws, [22, 12, 18])

    wb.save(path)


def build(state, letters=0):
    """生成月度清收进展 Excel，返回文件名与图表数据。"""
    s = summarize(state, letters)
    folder = OUTPUT / f"{state['batch']}_月报"
    folder.mkdir(parents=True, exist_ok=True)
    name = f"清收进展_{s['month']}.xlsx"
    _write_xlsx(folder / name, s)
    return {"folder": folder.name, "xlsx_name": name, "summary": s}
