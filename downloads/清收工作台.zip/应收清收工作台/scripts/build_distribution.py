"""构建可分发的离线工具包：解压 → 双击启动 → 浏览器自动打开。"""
from pathlib import Path
import shutil
import zipfile

SRC = Path(__file__).resolve().parent.parent
DIST = SRC.parent / "dist"
PKG = DIST / "应收清收工作台"

if DIST.exists():
    shutil.rmtree(DIST)
PKG.mkdir(parents=True)

# 1. 代码与模板
for folder in ("app", "static", "templates", "scripts"):
    shutil.copytree(
        SRC / folder, PKG / folder,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".DS_Store"),
    )

# 2. 依赖清单
shutil.copy2(SRC / "requirements.txt", PKG / "requirements.txt")

# 3. 干净演示数据
data_dst = PKG / "data"
data_dst.mkdir()
shutil.copy2(SRC / "data" / "engine.db", data_dst / "engine.db")
shutil.copy2(SRC / "data" / "模拟复核表.xlsx", data_dst / "模拟复核表.xlsx")
shutil.copy2(SRC / "data" / "复核表模板.xlsx", data_dst / "复核表模板.xlsx")
shutil.copytree(SRC / "data" / "collection_sample", data_dst / "模拟数据表_5张")
shutil.copytree(SRC / "data" / "output", data_dst / "output")

# 4. 一键启动脚本（ macOS / Windows ）
launcher = '''"""启动入口：监听 $PORT（默认 8791），绑定 0.0.0.0，启动后打开浏览器。"""
import os
import threading
import webbrowser
import uvicorn

PORT = int(os.environ.get("PORT", "8791"))


def _open_browser():
    try:
        webbrowser.open(f"http://127.0.0.1:{PORT}")
    except Exception:
        pass


if __name__ == "__main__":
    threading.Timer(1.5, _open_browser).start()
    uvicorn.run("app.main:app", host="0.0.0.0", port=PORT, log_level="warning")
'''
(PKG / "启动.py").write_text(launcher, encoding="utf-8")

mac = '''#!/bin/bash
cd "$(dirname "$0")"
echo "=========================================="
echo "  应收清收工作台 · 正在启动"
echo "=========================================="
if [ ! -d ".venv" ]; then
  echo "首次运行：正在创建环境并安装依赖，请稍候..."
  python3 -m venv .venv
fi
source .venv/bin/activate
python -m pip install -q -r requirements.txt 2>/dev/null || pip install -q -r requirements.txt
echo ""
echo "启动完成，浏览器将自动打开工作台。"
echo "若没自动打开，请手动访问 http://127.0.0.1:8791"
echo "关闭窗口即可停止服务。"
echo ""
python 启动.py
'''
mac_path = PKG / "① 双击启动（Mac）.command"
mac_path.write_text(mac, encoding="utf-8")
mac_path.chmod(0o755)

win = '''@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo   应收清收工作台 · 正在启动
echo ==========================================
if not exist ".venv" (
  echo 首次运行：正在创建环境并安装依赖，请稍候...
  python -m venv .venv
)
call .venv\\Scripts\\activate.bat
pip install -q -r requirements.txt
echo.
echo 启动完成，浏览器将自动打开工作台。
echo 若没自动打开，请手动访问 http://127.0.0.1:8791
echo 关闭窗口即可停止服务。
echo.
python 启动.py
pause
'''
(PKG / "① 双击启动（Windows）.bat").write_text(win, encoding="utf-8-sig")

# 5. 使用说明
readme = '''# 应收清收工作台 · 使用说明

一个把多项目、多商户、二十多个费项的欠费数据自动归集分级，
并一键生成催缴函、诉讼材料清单、月度清收进展的工具。
全部在本机运行，数据不上传、不联网、不花钱。

---

## 一、启动（只需一次，很简单）

**Mac 电脑**：双击 `① 双击启动（Mac）.command`
**Windows 电脑**：双击 `① 双击启动（Windows）.bat`

第一次双击会花几分钟自动准备环境，之后会快很多。
准备完成后浏览器会自动打开工作台，没自动打开就手动复制这个地址到浏览器：

    http://127.0.0.1:8791

**前提**：电脑上装了 Python 3（没装的话，去 python.org 下载安装，一路下一步即可）。
**停止使用**：关掉那个黑色/白色的命令行窗口就行。

> Mac 若提示"无法打开，因为来自身份不明的开发者"：
> 按住 Control 键再点文件 → 选"打开" → 确认"打开"即可。

---

## 二、打开后能看到什么

页面里已经预置了一批演示数据（24 个商户、3 个项目、32 条费项），
先随便点点熟悉一下：

- 中间是按"金额 × 账龄 × 风险"排好的**催收优先级清单**，最上面是最该催的
- 点任意商户能展开它欠了哪些费项
- 页面往下有三块现成的产出：
  - **催缴函**：每户一份 Word + PDF，可下载
  - **诉讼材料清单**：每户一份 Word，外加一张 Excel 汇总
  - **月度清收进展**：一份 Excel 月报，页面上还有分档柱状图
- 最上面右上角"函件信息设置"里，可以改公司名称、开户行、账号、联系人

---

## 三、换成你们自己的数据

1. 点页面上的 **下载模拟数据表**，拿到 5 张表的样板，看字段怎么填
2. 把你们真实的租金表、物业费表、其它费项表、风险表，按样板格式整理好
   （列名写法不一致也认，比如"应收金额"和"欠款金额"都能识别）
3. 把整理好的表一起拖进页面的导入区
4. 工具自动扣减减免、统一口径、算分分级、排好优先级
5. 在清单里勾选要催的商户，点对应按钮生成函件 / 诉讼清单 / 月报

**打分口径**（可在代码里调）：风险信号 40% + 账龄 35% + 欠费金额 25%。
风险信号看四类：进了诉讼、催过多次没效果、快撤场、长期零回款。
70 分及以上为高优先级，45–70 为中等，其余为低。

---

## 四、几个常见疑问

**Q：数据是存在哪的？会丢吗？**
A：全部存在本机的 `data/engine.db` 里，生成的文件在 `data/output/` 里，关掉重开都还在。

**Q：要联网吗？会不会花钱？**
A：使用时不用联网，也不调用任何付费接口。只有第一次安装依赖需要联网。

**Q：可以给多个人用吗？**
A：这个包是单机版，装在一台电脑上大家轮流用。如果要把数据同步给多人，
   或者想做成网页链接让别人直接打开，需要额外部署，可以找我。

**Q：公司法人的账号、电话这些要改在哪？**
A：页面右上角"函件信息设置"，改完重新生成函件即可。包里预置的是演示信息，正式用之前记得换掉。

---

需要改函件措辞、调整分级口径或打分权重，文件都在 `templates/` 和 `app/collector.py` 里，
也可以直接告诉我怎么改。
'''
(PKG / "使用说明.md").write_text(readme, encoding="utf-8")

# 6. 打包 zip（排除运行时缓存）
zip_path = DIST / "应收清收工作台.zip"
if zip_path.exists():
    zip_path.unlink()
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for f in PKG.rglob("*"):
        if f.is_file() and "__pycache__" not in f.parts:
            z.write(f, f.relative_to(DIST))

size_mb = zip_path.stat().st_size / 1024 / 1024
print(f"分发包已生成：{zip_path.resolve()}")
print(f"体积：{size_mb:.2f} MB")
print(f"文件数：{len([1 for _ in PKG.rglob('*') if _.is_file()])}")
