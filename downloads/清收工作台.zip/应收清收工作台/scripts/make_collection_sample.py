"""生成多项目、多商户、多费项的分散模拟表。"""

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

BASE = Path(__file__).resolve().parent.parent / "data" / "collection_sample"
BASE.mkdir(parents=True, exist_ok=True)

PROJECTS = ["星汇广场", "云顶中心", "湖畔里"]
FEES = ["租金", "物业费", "推广费", "空调费", "能耗费", "停车费", "广告位费",
        "管理费", "保洁费", "水电费", "违约金", "滞纳金", "场地费", "宽带费",
        "垃圾清运费", "装修管理费", "活动赞助费", "空调加时费", "招牌费", "仓储费"]

MERCHANTS = [
    ("星野咖啡", "A101", 12800, 0, 68, "", "2", "", "0"),
    ("优鲜生活超市", "A102", 35600, 500, 95, "", "3", "", "0"),
    ("拾光书店", "A103", 4200, 0, 32, "", "1", "", "860"),
    ("青禾瑜伽馆", "B201", 9800, 0, 61, "已立案", "2", "", "0"),
    ("麦香烘焙", "B202", 2650, 0, 24, "", "1", "", "1200"),
    ("云顶理发店", "B203", 1800, 0, 8, "", "", "", "1800"),
    ("悦动健身", "C301", 21800, 2000, 88, "诉讼中", "3", "拟撤场", "0"),
    ("花间花艺", "C302", 3200, 0, 40, "", "2", "", "600"),
    ("小满便利店", "C303", 7650, 0, 55, "", "1", "", "0"),
    ("木言家居", "D401", 15200, 1000, 72, "", "2", "停业", "0"),
    ("甜心甜品", "D402", 1980, 0, 12, "", "", "", "1980"),
    ("蓝鲸洗衣", "D403", 5400, 0, 36, "", "1", "", "5400"),
    ("半山茶舍", "E501", 8900, 0, 51, "", "2", "", "0"),
    ("果果乐园", "E502", 12300, 800, 79, "已起诉", "3", "", "0"),
    ("老街火锅", "F601", 18700, 0, 104, "诉讼中", "4", "退租意向", "0"),
    ("转角花店", "F602", 3400, 0, 28, "", "1", "", "3400"),
    ("一键洗车", "F603", 4600, 0, 44, "", "2", "", "0"),
    ("晨光文具", "G701", 6800, 300, 58, "", "2", "", "0"),
    ("南山面馆", "G702", 5200, 0, 33, "", "1", "", "5200"),
    ("星光影院", "G703", 42800, 5000, 132, "已立案", "4", "拟撤场", "0"),
    ("悠然茶坊", "H801", 7600, 0, 47, "", "2", "", "0"),
    ("叮咚果园", "H802", 2900, 0, 19, "", "1", "", "2900"),
    ("漫步鞋店", "H803", 11500, 0, 66, "", "3", "", "0"),
    ("好味便当", "H804", 8300, 600, 73, "", "2", "停业", "0"),
]


def write_sheet(path, header, rows, widths):
    import csv

    if path.suffix.lower() == ".csv":
        with path.open("w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.writer(fh)
            writer.writerow(header)
            writer.writerows(rows)
        print(f"  {path.name}: {len(rows)} 行")
        return
    wb = Workbook()
    ws = wb.active
    ws.append(header)
    for r in rows:
        ws.append(r)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1D1D1F")
        c.alignment = Alignment(horizontal="center")
    for col, w in zip("ABCDEFGHIJKL", widths):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"
    wb.save(path)
    print(f"  {path.name}: {len(rows)} 行")


def main():
    print("生成分散模拟表：")

    r1, r2, r3 = [], [], []
    for i, (name, shop, amount, reduction, age, lit, coll, exit_, pay) in enumerate(MERCHANTS):
        project = PROJECTS[i % 3]
        fee = FEES[i % len(FEES)]
        base = [project, shop, name, fee, amount, reduction, age, f"2026年{1 + i % 10}-{2 + i % 10}月"]
        if i % 3 == 0:
            r1.append(base)
        elif i % 3 == 1:
            r2.append(base)
        else:
            r3.append(base)

    write_sheet(
        BASE / "星汇广场_租金物业费表.xlsx",
        ["项目", "铺位号", "商户名称", "费项", "应收金额", "减免金额", "账龄天数", "欠费期间"],
        r1,
        [14, 10, 18, 12, 14, 12, 12, 18],
    )
    write_sheet(
        BASE / "云顶中心_费用台账.csv",
        ["项目", "铺位号", "商户名称", "费用项目", "应收", "减免", "逾期天数", "期间"],
        r2,
        [14, 10, 18, 12, 14, 12, 12, 18],
    )
    write_sheet(
        BASE / "湖畔里_应收明细.xlsx",
        ["项目名称", "商户编号", "客户名称", "收费项目", "欠款金额", "优惠金额", "欠费天数", "账期"],
        r3,
        [14, 10, 18, 12, 14, 12, 12, 18],
    )

    risk_rows = []
    for name, shop, amount, reduction, age, lit, coll, exit_, pay in MERCHANTS:
        risk_rows.append([name, shop, "是" if lit else "否", coll, exit_ or "正常", pay])
    write_sheet(
        BASE / "风险状态汇总表.xlsx",
        ["商户名称", "铺位号", "诉讼状态", "催缴次数", "撤场迹象", "回款情况"],
        risk_rows,
        [18, 10, 12, 12, 12, 12],
    )

    extra = [
        ["星汇广场", "A101", "星野咖啡", "推广费", 1200, 0, 45],
        ["星汇广场", "A102", "优鲜生活超市", "空调加时费", 860, 0, 52],
        ["云顶中心", "B201", "青禾瑜伽馆", "招牌费", 640, 0, 61],
        ["云顶中心", "C301", "悦动健身", "场地费", 2400, 200, 88],
        ["湖畔里", "D401", "木言家居", "仓储费", 1500, 0, 72],
        ["湖畔里", "F601", "老街火锅", "垃圾清运费", 380, 0, 104],
        ["星汇广场", "G703", "星光影院", "活动赞助费", 5600, 500, 132],
        ["云顶中心", "H803", "漫步鞋店", "装修管理费", 2200, 0, 66],
    ]
    write_sheet(
        BASE / "其它费项_补充表.xlsx",
        ["项目", "铺位号", "商户名称", "费项", "应收金额", "减免金额", "账龄天数"],
        extra,
        [14, 10, 18, 14, 14, 12, 12],
    )
    print(f"合计：{len(MERCHANTS)} 商户 / {len(MERCHANTS) + len(extra)} 条费项 / 5 张表")


if __name__ == "__main__":
    main()
