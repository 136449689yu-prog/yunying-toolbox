from pathlib import Path

from openpyxl import Workbook

OUT = Path(__file__).resolve().parent.parent / "data" / "复核表模板.xlsx"


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "复核后的欠费表"
    ws.append([
        "铺位号", "商户名称", "欠费金额", "欠费期间", "逾期天数",
        "函件类型", "复核状态", "复核人",
    ])
    ws.append(["A101", "示例商户", "1200.50", "2026年10月", "35", "一次", "已复核", "财务张三"])
    ws.append(["B202", "示例公司", "3800", "2026年9-10月", "62", "二次", "已复核", "财务张三"])
    ws.append(["C303", "未复核商户", "200", "2026年10月", "5", "一次", "待复核", "财务张三"])
    for col, width in zip("ABCDEFGH", [12, 20, 14, 18, 12, 12, 12, 14]):
        ws.column_dimensions[col].width = width
    wb.save(OUT)
    print(f"已生成 {OUT}")


if __name__ == "__main__":
    main()
