const $ = (s) => document.querySelector(s);
let state = { rows: [], batch: null, letters: [], audit: [], settings: {} };

function money(v) {
  return "¥" + Number(v || 0).toLocaleString("zh-CN", { minimumFractionDigits: 2 });
}

function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}

function msg(text, error = false) {
  const box = $("#import-msg");
  box.textContent = text;
  box.classList.toggle("error", error);
  box.hidden = !text;
}

function renderStats(rows) {
  const total = rows.reduce((s, r) => s + Number(r.amount), 0);
  const first = rows.filter((r) => r.notice_type === "一次函").length;
  const second = rows.length - first;
  const items = [
    ["复核记录", String(rows.length), ""],
    ["一次函", String(first), ""],
    ["二次函", String(second), ""],
    ["欠费总额", money(total), "small"],
  ];
  const box = $("#stats");
  box.replaceChildren();
  for (const [label, value, cls] of items) {
    const card = el("div", "stat");
    card.append(el("div", "stat-label", label), el("div", "stat-value " + cls, value));
    box.append(card);
  }
}

function renderChart(rows) {
  const top = [...rows].sort((a, b) => Number(b.amount) - Number(a.amount)).slice(0, 8);
  const max = Math.max(...top.map((r) => Number(r.amount)), 1);
  const box = $("#chart");
  box.replaceChildren();
  for (const r of top) {
    const row = el("div", "bar-row");
    const label = el("div", "bar-label", r.shop_no);
    label.title = r.shop_no + " · " + r.merchant;
    const track = el("div", "bar-track");
    const fill = el("div", "bar-fill");
    fill.style.width = (Number(r.amount) / max) * 100 + "%";
    track.append(fill);
    row.append(label, track, el("div", "bar-value", money(r.amount)));
    box.append(row);
  }
}

function renderRows(rows) {
  const body = $("#rows-body");
  body.replaceChildren();
  for (const r of rows) {
    const tr = el("tr");
    const check = el("input");
    check.type = "checkbox";
    check.checked = true;
    check.className = "row-check";
    check.value = String(r.id);
    check.addEventListener("change", updateSelected);
    tr.append(el("td", "check-col"));
    tr.lastChild.append(check);
    tr.append(el("td", "", r.shop_no), el("td", "", r.merchant));
    const amount = el("td", "num", money(r.amount));
    tr.append(amount, el("td", "", r.period || "—"));
    tr.append(el("td", "num", r.overdue_days || "—"));
    const type = el("td");
    type.append(el("span", "tag " + (r.notice_type === "二次函" ? "second" : "first"), r.notice_type));
    tr.append(type, el("td", "", r.reviewer || "—"));
    body.append(tr);
  }
  $("#data-section").hidden = false;
  $("#batch-tag").textContent = "批次 " + (state.batch || "");
  updateSelected();
}

function selectedIds() {
  return [...document.querySelectorAll(".row-check:checked")].map((n) => Number(n.value));
}

function updateSelected() {
  const n = selectedIds().length;
  $("#selected-count").textContent = `已选 ${n} 条，将为每条生成一份 Word 和一份 PDF`;
  const all = document.querySelectorAll(".row-check").length;
  $("#check-all").checked = n === all && all > 0;
}

function renderResult(letters, zip) {
  const section = $("#result-section");
  section.hidden = false;
  $("#result-summary").textContent = `已生成 ${letters.length} 份函件（每份含 Word 和 PDF），可逐份下载或一次打包。`;
  const list = $("#file-list");
  list.replaceChildren();
  for (const letter of letters) {
    const item = el("div", "file-item");
    const name = el("span", "", letter.shop_no + " · " + letter.notice_type);
    const links = el("span");
    for (const ext of ["docx", "pdf"]) {
      const a = el("a", "", ext.toUpperCase());
      a.href = `/api/download/${state.batch}/${encodeURIComponent(letter[ext + "_name"])}`;
      links.append(a, document.createTextNode(" "));
    }
    item.append(name, links);
    list.append(item);
  }
  const zipLink = $("#zip-link");
  zipLink.href = `/api/download/${state.batch}/${encodeURIComponent(zip)}`;
}

function renderAudit(audit) {
  const box = $("#audit-list");
  box.replaceChildren();
  if (!audit.length) {
    box.append(el("div", "caption", "暂无操作记录"));
    return;
  }
  for (const a of audit) {
    const item = el("div", "audit-item");
    item.append(el("strong", "", a.created_at.slice(0, 16).replace("T", " ")), el("span", "", a.action + " · " + a.detail));
    box.append(item);
  }
}

async function api(url, options) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "请求失败");
  return data;
}

async function upload(file) {
  msg("正在解析复核表…");
  const form = new FormData();
  form.append("file", file);
  try {
    const data = await api("/api/import", { method: "POST", body: form });
    state.rows = data.rows;
    state.batch = data.batch;
    state.letters = [];
    renderStats(data.rows);
    renderChart(data.rows);
    renderRows(data.rows);
    $("#result-section").hidden = true;
    msg(`导入成功：${data.count} 条已复核记录。核对无误后点「生成催费函」。`);
  } catch (err) {
    msg("导入失败：" + err.message, true);
  }
}

$("#choose-file").addEventListener("click", () => $("#file-input").click());
$("#file-input").addEventListener("change", (e) => {
  if (e.target.files[0]) upload(e.target.files[0]);
});
const zone = $("#drop-zone");
zone.addEventListener("dragover", (e) => { e.preventDefault(); zone.classList.add("drag-over"); });
zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
zone.addEventListener("drop", (e) => {
  e.preventDefault();
  zone.classList.remove("drag-over");
  if (e.dataTransfer.files[0]) upload(e.dataTransfer.files[0]);
});

$("#check-all").addEventListener("change", (e) => {
  document.querySelectorAll(".row-check").forEach((n) => { n.checked = e.target.checked; });
  updateSelected();
});

$("#generate").addEventListener("click", async () => {
  const ids = selectedIds();
  if (!ids.length) return;
  const btn = $("#generate");
  btn.disabled = true;
  btn.textContent = "生成中…";
  try {
    const data = await api("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ batch: state.batch, ids }),
    });
    state.letters = data.letters;
    renderResult(data.letters, data.zip);
    msg("");
    await loadState(false);
  } catch (err) {
    msg("生成失败：" + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "生成催费函";
  }
});

const modal = $("#settings-modal");
$("#open-settings").addEventListener("click", () => { modal.hidden = false; });
$("#close-settings").addEventListener("click", () => { modal.hidden = true; });
$("#cancel-settings").addEventListener("click", () => { modal.hidden = true; });
modal.addEventListener("click", (e) => { if (e.target === modal) modal.hidden = true; });
$("#settings-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const values = Object.fromEntries(new FormData(e.target));
  try {
    state.settings = await api("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(values),
    });
    modal.hidden = true;
    msg("函件信息已保存");
  } catch (err) {
    msg("保存失败：" + err.message, true);
  }
});

async function loadState(fillForm = true) {
  try {
    state = await api("/api/state");
    renderAudit(state.audit);
    if (state.rows.length) {
      renderStats(state.rows);
      renderChart(state.rows);
      renderRows(state.rows);
    }
    if (state.letters.length) renderResult(state.letters, `催费函_${state.batch}.zip`);
    if (fillForm) {
      for (const [key, value] of Object.entries(state.settings)) {
        const input = document.querySelector(`#settings-form [name="${key}"]`);
        if (input) input.value = value;
      }
    }
  } catch (err) {
    msg("加载失败：" + err.message, true);
  }
}

loadState();
