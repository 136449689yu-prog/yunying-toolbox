const $ = (s) => document.querySelector(s);
let state = null;

function money(v) {
  return "¥" + Number(v || 0).toLocaleString("zh-CN", { minimumFractionDigits: 2 });
}
function el(tag, cls, text) {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text !== undefined) n.textContent = text;
  return n;
}
function msg(text, error = false) {
  const box = $("#import-msg");
  box.textContent = text;
  box.classList.toggle("error", error);
  box.hidden = !text;
}
function flags(text) {
  if (!text) return [];
  return text.split("、").filter(Boolean);
}

function render(s) {
  state = s;
  const bar = $("#check-bar");
  bar.className = "check-bar " + (s.check_pass ? "ok" : "bad");
  $("#check-text").textContent = s.check_pass
    ? "合计校验通过，应收 − 减免 = 实欠"
    : "合计校验不通过，请检查数据";
  $("#check-formula").textContent =
    `${money(s.receivable_total)} − ${money(s.reduction_total)} = ${money(s.net_total)}`;
  $("#batch-tag").textContent = `批次 ${s.batch}`;

  const stats = [
    ["商户", String(s.merchant_count), ""],
    ["费项", String(s.row_count), ""],
    ["项目", String(s.project_count), ""],
    ["实欠合计", money(s.net_total), "small"],
  ];
  const box = $("#stats");
  box.replaceChildren();
  for (const [label, value, cls] of stats) {
    const card = el("div", "stat");
    card.append(el("div", "stat-label", label), el("div", "stat-value " + cls, value));
    box.append(card);
  }

  const levels = ["高", "中", "低"];
  const colors = { 高: "#D64541", 中: "#E39B24", 低: "#2E8B57" };
  const lg = $("#level-grid");
  lg.replaceChildren();
  const dist = $("#dist-bar");
  dist.replaceChildren();
  for (const level of levels) {
    const group = s.merchants.filter((m) => m.level === level);
    const total = group.reduce((a, m) => a + Number(m.net_total), 0);
    const card = el("div", "level-card " + { 高: "high", 中: "mid", 低: "low" }[level]);
    card.append(
      el("div", "label", level + "优先级"),
      el("div", "num", String(group.length)),
      el("div", "sum", money(total))
    );
    lg.append(card);
    const seg = el("span");
    seg.style.width = (group.length / Math.max(s.merchant_count, 1) * 100) + "%";
    seg.style.background = colors[level];
    dist.append(seg);
  }

  const body = $("#prio-body");
  body.replaceChildren();
  if (!s.merchants.length) {
    const tr = el("tr");
    const td = el("td", "empty", "暂无数据，先载入模拟数据或导入表格");
    td.colSpan = 9;
    tr.append(td);
    body.append(tr);
  }
  for (const m of s.merchants) {
    const tr = el("tr");
    tr.append(el("td", "rank", String(m.rank)));
    const pill = el("td");
    pill.append(el("span", "level-pill " + m.level, m.level));
    tr.append(pill, el("td", "", m.merchant), el("td", "", `${m.project} · ${m.shop_no || "—"}`));
    tr.append(el("td", "num", money(m.net_total)), el("td", "num", m.age_days + " 天"));
    const riskTd = el("td");
    for (const f of flags(m.risk_flags)) riskTd.append(el("span", "risk-tag", f));
    tr.append(riskTd, el("td", "num score-cell", m.score.toFixed(1)));
    const caretTd = el("td");
    caretTd.append(el("span", "caret", "▸"));
    tr.append(caretTd);

    const detailTr = el("tr", "fee-detail");
    detailTr.hidden = true;
    const detailTd = el("td");
    detailTd.colSpan = 9;
    const rows = s.items.filter((i) => i.merchant === m.merchant);
    for (const item of rows) {
      const line = el("div", "bar-row");
      line.style.marginBottom = "4px";
      line.append(
        el("span", "", item.fee_item),
        el("span", "caption", `应收 ${money(item.receivable)} · 减免 ${money(item.reduction)}`),
        el("span", "num", money(item.net_amount))
      );
      line.lastChild.style.marginLeft = "auto";
      detailTd.append(line);
    }
    detailTr.append(detailTd);
    tr.addEventListener("click", () => {
      detailTr.hidden = !detailTr.hidden;
      caretTd.firstChild.classList.toggle("open", !detailTr.hidden);
    });
    body.append(tr, detailTr);
  }
  $("#result-section").hidden = false;
}

async function api(url, options) {
  const res = await fetch(url, options);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || "请求失败");
  return data;
}

$("#choose-files").addEventListener("click", () => $("#file-input").click());
function showChips(files) {
  const box = $("#file-chips");
  box.replaceChildren();
  for (const f of files) box.append(el("span", "file-chip", f.name));
}
$("#file-input").addEventListener("change", (e) => {
  showChips([...e.target.files]);
});
const zone = $("#drop-zone");
zone.addEventListener("dragover", (e) => { e.preventDefault(); zone.classList.add("drag-over"); });
zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
zone.addEventListener("drop", (e) => {
  e.preventDefault();
  zone.classList.remove("drag-over");
  const files = [...e.dataTransfer.files];
  showChips(files);
  upload(files);
});

async function upload(files) {
  if (!files.length) return;
  msg("正在归集…");
  const form = new FormData();
  for (const f of files) form.append("files", f);
  try {
    const data = await api("/api/collection/import", { method: "POST", body: form });
    render(data.state);
    msg(`归集完成：${data.state.row_count} 条费项 → ${data.state.merchant_count} 商户`);
  } catch (err) {
    msg("归集失败：" + err.message, true);
  }
}

$("#load-sample").addEventListener("click", async () => {
  const btn = $("#load-sample");
  btn.disabled = true;
  btn.textContent = "载入中…";
  try {
    const data = await api("/api/collection/load-sample", { method: "POST" });
    render(data.state);
    msg("模拟数据已载入：3 个项目、24 商户、32 条费项，分散在 5 张表");
  } catch (err) {
    msg("载入失败：" + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = "载入模拟数据（5 张表）";
  }
});

(async () => {
  try {
    const data = await api("/api/collection/state");
    if (data.state) render(data.state);
  } catch (err) {
    msg("加载失败：" + err.message, true);
  }
})();
