﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo   应收清收工作台 · 正在启动
echo ==========================================
if not exist ".venv" (
  echo 首次运行：正在创建环境并安装依赖，请稍候...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
echo.
echo 启动完成，浏览器将自动打开工作台。
echo 若没自动打开，请手动访问 http://127.0.0.1:8791
echo 关闭窗口即可停止服务。
echo.
python 启动.py
pause
