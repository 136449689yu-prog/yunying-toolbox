"""启动入口：监听 $PORT（默认 8791），绑定 0.0.0.0，启动后打开浏览器。"""
import os
import threading
import webbrowser
import uvicorn

PORT = int(os.environ.get("PORT", "8791"))


def _open_browser():
    try:
        webbrowser.open(f"http://127.0.0.1:{PORT}")
    except Exception:
        pass


if __name__ == "__main__":
    threading.Timer(1.5, _open_browser).start()
    uvicorn.run("app.main:app", host="0.0.0.0", port=PORT, log_level="warning")
