#!/bin/bash
cd "$(dirname "$0")"
echo "=========================================="
echo "  寻客 · 运营工具合集"
echo "=========================================="
echo ""
echo "请选择要打开的工具："
echo "  1. 运营工具台"
echo "  2. 运营工具台（真实数据版）"
echo "  3. 台账清洗台"
echo "  4. 共享数据工作台"
echo "  0. 退出"
echo ""
read -p "请输入数字后回车：" choice
case $choice in
  1) open "运营工具台.html";;
  2) open "运营工具台-真实数据版.html";;
  3) open "台账清洗台.html";;
  4) open "共享数据工作台.html";;
  0) exit 0;;
  *) echo "无效选择";;
esac
