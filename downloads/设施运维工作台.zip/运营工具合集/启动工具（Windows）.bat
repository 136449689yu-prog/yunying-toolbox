﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo   寻客 · 运营工具合集
echo ==========================================
echo.
echo 请选择要打开的工具：
echo   1. 运营工具台
echo   2. 运营工具台（真实数据版）
echo   3. 台账清洗台
echo   4. 共享数据工作台
echo   0. 退出
echo.
set /p choice=请输入数字后回车：
if "%choice%"=="1" start "" "运营工具台.html"
if "%choice%"=="2" start "" "运营工具台-真实数据版.html"
if "%choice%"=="3" start "" "台账清洗台.html"
if "%choice%"=="4" start "" "共享数据工作台.html"
if "%choice%"=="0" exit
timeout /t 2 >nul
